import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { allowedEstablishEndpoints } from "./auth/establish-endpoints.mjs";
import { serverAuth } from "./auth-hooks.mjs";
import { answerModuleRoute } from "./module-event.mjs";
import { isNonNullObject, isRecord, isString } from "./type-guards.mjs";
import {
  matchModuleRoute,
  mayHaveModuleRoute,
  moduleRouteMethods,
  resolveServerDeclarations,
} from "./module-routes.mjs";
import {
  allowedPublicEndpoints,
  environmentBackendProxies,
  readDeclaredBackendProxies,
} from "./public-endpoints.mjs";
import { reachesBackend } from "./request-routing.mjs";

import { frontendRegistryOf, serverOptionsOf } from "./generated-files.mjs";
import { publicOptionsOf } from "./public-options.mjs";
/** @typedef {import("./module-route-types.mjs").ServerModuleDeclaration} ServerModuleDeclaration */
/**
 * What a handler of a module reads besides its request.
 *
 * @typedef {object} ModuleContext
 * @property {{ id: string, options: unknown, privateOptions: unknown }} module
 * @property {{ authEstablishEndpoints: readonly string[] }} app
 * @property {string | undefined} authOwner The module that owns sign-in
 */
/**
 * A deployment's data, which the server hands to a set of server modules.
 *
 * @typedef {object} Deployment
 * @property {Record<string, unknown>} [publicOptions] Each module's public options by id
 * @property {Record<string, unknown>} [privateOptions] Each module's private options by id
 * @property {() => readonly string[]} [authEstablishEndpoints]
 * @property {import("./public-endpoints.mjs").PublicEndpoint[]} [publicEndpoints]
 * @property {import("./backend-proxies.mjs").ManifestProxy[]} [backendProxies]
 * @property {(message: string) => void} warn
 */
/** @typedef {ReturnType<typeof createServerModules>} ServerModules */

const WORKSPACE_ROOT = new URL("../", import.meta.url);
const SOURCE_LOADER = "/server-modules.generated.ts";
const BUILT_LOADER = new URL(
  "dist/server-modules/server-modules.generated.js",
  WORKSPACE_ROOT,
);
const REGISTRY_FILE = new URL(
  "generated-frontend-modules.json",
  WORKSPACE_ROOT,
);
const SERVER_OPTIONS_FILE = new URL(
  "generated-server-options.json",
  WORKSPACE_ROOT,
);

/** @type {Promise<ServerModuleDeclaration[]> | undefined} */
let builtDeclarations;
/** @type {ServerModuleDeclaration[]} */
let lastDeclarations = [];
/** @type {string | undefined} */
let lastLoadError;
/** @type {WeakMap<ServerModuleDeclaration[], ServerModules>} */
const resolved = new WeakMap();

/**
 * @param {URL} url
 * @param {unknown} fallback
 * @returns {unknown} The file's JSON, the fallback when it cannot be read
 */
function readJsonFile(url, fallback) {
  try {
    return JSON.parse(readFileSync(url, "utf8"));
  } catch {
    return fallback;
  }
}

const UNSAFE_KEYS = new Set(["__proto__", "constructor", "prototype"]);

/**
 * The object holding `path`'s last key, and that key, when every key up to it
 * is own.
 *
 * @param {Record<string, unknown>} target
 * @param {string[]} path
 * @returns {{ holder: Record<string, unknown>, key: string } | undefined}
 */
function slotOf(target, path) {
  const key = path.at(-1);
  if (key === undefined || UNSAFE_KEYS.has(key)) return undefined;
  let node = target;
  for (const step of path.slice(0, -1)) {
    if (UNSAFE_KEYS.has(step) || !Object.hasOwn(node, step)) return undefined;
    const next = node[step];
    if (!isRecord(next)) return undefined;
    node = next;
  }
  return { holder: node, key };
}

/**
 * Sets `value` at `path` when the object holding it exists but lacks it.
 *
 * @param {Record<string, unknown>} target
 * @param {string[]} path
 * @param {string} value
 */
function fillPath(target, path, value) {
  const slot = slotOf(target, path);
  if (
    slot &&
    (slot.holder[slot.key] === undefined || slot.holder[slot.key] === "")
  )
    slot.holder[slot.key] = value;
}

/**
 * Sets `value` at `path` only where the build left an empty string.
 *
 * @param {Record<string, unknown>} target
 * @param {string[]} path
 * @param {string} value
 */
function fillEmptied(target, path, value) {
  const slot = slotOf(target, path);
  if (
    slot &&
    Object.hasOwn(slot.holder, slot.key) &&
    slot.holder[slot.key] === ""
  )
    slot.holder[slot.key] = value;
}

/**
 * Each module's private options, the secrets the manifest publishes first:
 * the environment variable of a secret (`DMS_HTML_RENDER_SECRET`,
 * `DMS_OAUTH_RELAY_SECRET`) only fills in a section that carries none.
 *
 * @param {Record<string, Record<string, unknown>>} modules The private options by module id, as the manifest published
 *   them
 * @param {Record<string, string[]>} environment The variables by the path of the secret they stand for
 * @param {NodeJS.ProcessEnv} env The process environment
 */
export function privateOptionsWithFallbacks(modules, environment, env) {
  for (const options of Object.values(modules))
    for (const [name, path] of Object.entries(environment))
      if (env[name]) fillPath(options, path, env[name]);
  return modules;
}

/**
 * Each string leaf of `value`, array items included, with its path.
 *
 * @param {unknown} value
 * @param {string[]} [path]
 * @returns {Generator<[string[], string]>}
 */
function* stringLeaves(value, path = []) {
  if (isString(value)) yield [path, value];
  else if (isNonNullObject(value))
    for (const [key, child] of Object.entries(value))
      yield* stringLeaves(child, [...path, key]);
}

/**
 * Fills the private values a build left empty from `DMS_PRIVATE_OPTIONS`, a
 * JSON object of private options by module id
 * (`{"acme__shop-frontend-vue":{"apiKey":"…"}}`): any module's secrets, where
 * `DMS_HTML_RENDER_SECRET` and `DMS_OAUTH_RELAY_SECRET` name two of them. Only
 * a value the build emptied is filled, array items included: a value the
 * manifest carries wins, and no option or section is added or replaced.
 *
 * @param {Record<string, Record<string, unknown>>} modules The private options by module id
 * @param {string | undefined} json The variable's value; nothing is filled when unset
 * @param {(message: string) => void} warn Reports a value that is not a JSON object, never its content
 */
export function privateOptionsFromJson(modules, json, warn) {
  if (!json) return modules;
  /** @type {unknown} */
  let given;
  try {
    given = JSON.parse(json);
  } catch {
    given = undefined;
  }
  if (!isNonNullObject(given) || Array.isArray(given)) {
    warn("DMS_PRIVATE_OPTIONS is not a JSON object of options by module id");
    return modules;
  }
  for (const [id, options] of Object.entries(given)) {
    if (UNSAFE_KEYS.has(id) || !Object.hasOwn(modules, id)) continue;
    for (const [path, value] of stringLeaves(options))
      if (path.length > 0) fillEmptied(modules[id], path, value);
  }
  return modules;
}

/** @param {NodeJS.ProcessEnv} [env] */
function readPrivateOptions(env = process.env) {
  const { modules, environment } = serverOptionsOf(
    readJsonFile(SERVER_OPTIONS_FILE, {}),
  );
  return privateOptionsFromJson(
    privateOptionsWithFallbacks(modules, environment, env),
    env.DMS_PRIVATE_OPTIONS,
    (message) => console.warn(message),
  );
}

function readPublicOptions() {
  return publicOptionsOf(
    frontendRegistryOf(readJsonFile(REGISTRY_FILE, { modules: [] })),
  );
}

/**
 * @param {import("vite").ViteDevServer | undefined} devServer
 * @returns {Promise<ServerModuleDeclaration[]>}
 */
async function loadDeclarations(devServer) {
  if (devServer)
    // oxlint-disable-next-line typescript/no-unsafe-return -- `ssrLoadModule` types every module `Record<string, any>`; the loader is the generated `server-modules.generated.ts`, which exports `serverModules`.
    return (await devServer.ssrLoadModule(SOURCE_LOADER)).serverModules;
  if (!existsSync(fileURLToPath(BUILT_LOADER))) return [];
  builtDeclarations ??= import(BUILT_LOADER.href).then(
    // oxlint-disable-next-line typescript/no-unsafe-return -- the build of that same generated module is imported by a URL computed at run time, so it is untyped.
    (loaded) => loaded.serverModules,
  );
  return builtDeclarations;
}

/**
 * The declarations to serve. A module entry that fails to load in development
 * (a syntax error being typed) is reported once, and the last routes that
 * loaded keep answering meanwhile.
 *
 * @param {import("vite").ViteDevServer | undefined} devServer
 */
async function currentDeclarations(devServer) {
  try {
    lastDeclarations = (await loadDeclarations(devServer)) ?? [];
    lastLoadError = undefined;
  } catch (error) {
    if (!devServer) throw error;
    const message = error instanceof Error ? error.message : String(error);
    if (message !== lastLoadError)
      console.error("DMS server modules failed to load", error);
    lastLoadError = message;
  }
  return lastDeclarations;
}

/**
 * A set of server modules, resolved for a deployment.
 *
 * `authOwner` is the module whose sealed cookies are the `dms_*` ones.
 *
 * @param {readonly ServerModuleDeclaration[]} declarations `{ id, priority, setup }` per module with a dms.server.ts
 * @param {Deployment} deployment `{ publicOptions, privateOptions, authEstablishEndpoints,
 *   publicEndpoints, backendProxies, warn }`: each module's options by id,
 *   the session-opening endpoints as a function (the environment can change
 *   them), the public endpoints, the backend proxies the manifest declares
 *   (`{ module, path, auth? }`), and where declaration problems are reported
 * @returns `{ routes, auth, context(id), serverAuth }`: `context` is what a
 *   handler of that module reads besides its request, `serverAuth` the
 *   session logic the module owning sign-in provides (see `auth-hooks.mjs`)
 */
export function createServerModules(declarations, deployment) {
  const resolution = resolveServerDeclarations(
    declarations,
    deployment.warn,
    deployment.publicEndpoints ?? [],
    deployment.backendProxies ?? [],
  );
  const context = (/** @type {string} */ id) => ({
    module: {
      id,
      options: deployment.publicOptions?.[id],
      privateOptions: deployment.privateOptions?.[id],
    },
    app: {
      authEstablishEndpoints: deployment.authEstablishEndpoints?.() ?? [],
    },
    authOwner: resolution.auth?.id,
  });
  return {
    ...resolution,
    context,
    serverAuth: serverAuth(resolution.auth, context),
  };
}

/**
 * Resolved once per set of declarations: in development, once per edit.
 *
 * @param {ServerModuleDeclaration[]} declarations
 */
function serverModules(declarations) {
  let modules = resolved.get(declarations);
  if (!modules) {
    modules = createServerModules(declarations, {
      publicOptions: readPublicOptions(),
      privateOptions: readPrivateOptions(),
      authEstablishEndpoints: () => allowedEstablishEndpoints(),
      publicEndpoints: allowedPublicEndpoints(),
      backendProxies: [
        ...readDeclaredBackendProxies(),
        ...environmentBackendProxies(),
      ],
      warn: (message) => console.warn(message),
    });
    resolved.set(declarations, modules);
  }
  return modules;
}

/**
 * The server modules of this deployment, resolved.
 *
 * Loads what the frontend modules declare in their `dms.server.ts` and hands a
 * request to the module route it reaches. In development the declarations come
 * from Vite (`ssrLoadModule`), so an edited entry or handler answers on the
 * next request; in production from the bundle `ajs dms build` makes
 * (`dist/server-modules`). A workspace built before the feature has none.
 *
 * @param {import("vite").ViteDevServer | undefined} devServer Vite in development, `undefined` in production
 */
export async function loadServerModules(devServer) {
  return serverModules(await currentDeclarations(devServer));
}

/**
 * Answers `request` with the module route it reaches, if any. A path a
 * module route serves is the module's for every method: another method is
 * answered `405`.
 *
 * @param {import("./request-target.mjs").ServerRequest} request The Node request
 * @param {import("node:http").ServerResponse} response The Node response
 * @param {string} pathname The request's normalized path
 * @param {ServerModules} modules What `loadServerModules` or `createServerModules` returned
 * @returns Whether a module route answered
 */
export async function handleModuleRoute(request, response, pathname, modules) {
  if (!mayHaveModuleRoute(pathname)) return false;
  const reached = matchModuleRoute(modules.routes, request.method, pathname);
  if (!reached) {
    const allowed = moduleRouteMethods(modules.routes, pathname);
    if (!allowed.length) return false;
    response.writeHead(405, {
      allow: allowed.join(", "),
      "content-type": "application/json",
    });
    response.end(JSON.stringify({ message: "Method not allowed" }));
    return true;
  }
  await answerModuleRoute({
    request,
    response,
    route: reached.route,
    params: reached.params,
    view: modules.serverAuth.view,
    isProxiedPath: (path) => reachesBackend(path, modules),
    ...modules.context(reached.route.id),
  });
  return true;
}
