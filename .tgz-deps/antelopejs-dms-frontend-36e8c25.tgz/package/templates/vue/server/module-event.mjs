import { Readable } from "node:stream";
import { backend, json, RequestBodyError } from "./auth/backend.mjs";
import {
  clientIp,
  CROSS_ORIGIN_ERROR,
  isSameOrigin,
  requestScheme,
} from "./auth/client-ip.mjs";
import {
  clearSealedCookie,
  clearSession,
  readSealedCookie,
  readSession,
  SESSION_COOKIE,
  setRequestSession,
  writeSealedCookie,
  writeSession,
} from "./auth/session.mjs";
import { renderEmailTemplate } from "./email.mjs";
import {
  isBackendUrl,
  relayableCookies,
  relayedLocation,
} from "./proxy-redirects.mjs";
import { backendUrl } from "./request-target.mjs";
import {
  isFunction,
  isNumber,
  isObjectLike,
  isRecord,
  isString,
} from "./type-guards.mjs";
import { pipeWebBody } from "./web-body.mjs";

/** @typedef {import("node:http").IncomingMessage} IncomingMessage */
/** @typedef {import("./request-target.mjs").ServerRequest} ServerRequest */
/** @typedef {import("node:http").ServerResponse} ServerResponse */
/** @typedef {import("../server-module.ts").DmsServerEvent} ServerEvent */
/** @typedef {import("../server-module.ts").DmsSession} Session */
/** @typedef {(session: Session | undefined) => import("../server-module.ts").DmsPublicSession} SessionView */
/**
 * What an event is made from.
 *
 * @typedef {object} EventContext
 * @property {ServerRequest} request
 * @property {ServerResponse} response
 * @property {Pick<import("./module-route-types.mjs").ServerRoute, "bodyLimit">} route
 * @property {Readonly<Record<string, string>>} params
 * @property {{ id: string, options?: unknown, privateOptions?: unknown }} module
 * @property {{ authEstablishEndpoints?: readonly string[] }} [app]
 * @property {SessionView} [view] What a session shows a page
 * @property {string} [authOwner] The module that owns sign-in
 */

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);
const COOKIE_NAME = /^[A-Za-z0-9_-]{1,64}$/;
/** The sealed cookies of the module that owns sign-in: session, accounts, flows. */
const RESERVED_COOKIE_PREFIX = "dms_";
const BODY_TOO_LARGE = "Request body too large";

/** @param {IncomingMessage} request */
function requestOrigin(request) {
  const host = request.headers.host;
  try {
    return new URL(`${requestScheme(request)}://${host}`).origin;
  } catch {
    return "http://frontend.local";
  }
}

/** @param {IncomingMessage} request */
function requestHeaders(request) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(request.headers)) {
    if (name.startsWith(":") || value === undefined) continue;
    for (const entry of [value].flat()) headers.append(name, entry);
  }
  return headers;
}

/**
 * The request body as a Web stream that errors past `limit` bytes.
 *
 * @param {IncomingMessage} request
 * @param {number} limit
 */
function limitedBody(request, limit) {
  let size = 0;
  return Readable.toWeb(request).pipeThrough(
    new TransformStream({
      transform(/** @type {Uint8Array} */ chunk, controller) {
        size += chunk.byteLength;
        if (size > limit)
          controller.error(new RequestBodyError(413, BODY_TOO_LARGE));
        else controller.enqueue(chunk);
      },
    }),
  );
}

/**
 * @param {ServerRequest} request
 * @param {EventContext["route"]} route
 */
function webRequest(request, route) {
  const url = new URL(request.url, requestOrigin(request));
  const hasBody = !["GET", "HEAD"].includes(request.method);
  const declaredLength = Number(request.headers["content-length"] ?? 0);
  if (hasBody && declaredLength > route.bodyLimit)
    throw new RequestBodyError(413, BODY_TOO_LARGE);
  return new Request(url, {
    method: request.method,
    headers: requestHeaders(request),
    body: hasBody ? limitedBody(request, route.bodyLimit) : undefined,
    duplex: "half",
  });
}

/**
 * @param {Request} webRequestValue
 * @returns {Promise<unknown>}
 */
async function readJson(webRequestValue) {
  if (!webRequestValue.body) return {};
  /** @type {Uint8Array[]} */
  const chunks = [];
  const reader = webRequestValue.body.getReader();
  for (;;) {
    const read = await reader.read();
    if (read.done) break;
    /** @type {unknown} */
    const chunk = read.value;
    if (!(chunk instanceof Uint8Array))
      throw new RequestBodyError(400, "Invalid request body");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new RequestBodyError(400, "Invalid request body");
  }
}

/** @param {unknown} name */
function checkedCookieName(name) {
  if (!isString(name) || !COOKIE_NAME.test(name))
    throw new Error(`Invalid cookie name: ${String(name)}`);
  if (name === SESSION_COOKIE)
    throw new Error(
      `The ${SESSION_COOKIE} cookie is the session's: use event.session`,
    );
  return name;
}

/**
 * @param {IncomingMessage} request
 * @param {ServerResponse} response
 * @param {SessionView | undefined} view
 * @returns {ServerEvent["session"]}
 */
function sessionAccess(request, response, view) {
  return {
    read: () => readSession(request),
    view: () => view?.(readSession(request)) ?? {},
    write(session) {
      session.updatedAt = Date.now();
      writeSession(response, session);
    },
    clear: () => clearSession(response),
    useForRequest: (session) => setRequestSession(request, session),
  };
}

/**
 * The name a module's sealed cookie takes in the jar. The module that owns
 * sign-in (`registerAuth`) names its own, the `dms_*` ones included; any other
 * module's are prefixed with its id and a dot, which no name of the owner's
 * holds, so no module reads or overwrites another's, nor the owner's session
 * and account cookies.
 *
 * @param {unknown} name
 * @param {string} moduleId
 * @param {string | undefined} authOwner
 */
function moduleCookieName(name, moduleId, authOwner) {
  const checked = checkedCookieName(name);
  if (moduleId === authOwner) return checked;
  if (checked.startsWith(RESERVED_COOKIE_PREFIX))
    throw new Error(
      `The ${RESERVED_COOKIE_PREFIX}* cookies belong to the module that owns sign-in` +
        `${authOwner ? ` (${authOwner})` : ""}: choose another name than ${checked}`,
    );
  return `${String(moduleId).replaceAll(/[^A-Za-z0-9_-]/g, "-")}.${checked}`;
}

/**
 * @param {IncomingMessage} request
 * @param {ServerResponse} response
 * @param {string} moduleId
 * @param {string | undefined} authOwner
 * @returns {ServerEvent["cookies"]}
 */
function cookieAccess(request, response, moduleId, authOwner) {
  const named = (/** @type {unknown} */ name) =>
    moduleCookieName(name, moduleId, authOwner);
  return {
    readSealed: (name, accepts) => {
      const value = readSealedCookie(request, named(name));
      return value !== undefined && accepts(value) ? value : undefined;
    },
    writeSealed: (name, value, options = {}) =>
      writeSealedCookie(
        response,
        named(name),
        value,
        options.maxAge,
        options.path ?? "/",
      ),
    clear: (name, options = {}) =>
      clearSealedCookie(response, named(name), options.path ?? "/"),
  };
}

/** @param {unknown} value */
function frozenCopy(value) {
  return Object.freeze(structuredClone(value ?? {}));
}

/**
 * The event a handler receives.
 *
 * What a module route handler receives and how its answer is written: the Web-
 * standard request, the session, the module's sealed cookies, the backend, and
 * the defaults every route gets once (same-origin on unsafe methods, a body
 * limit, `no-store`). See `server-module.ts` for the types a module reads.
 *
 * @param {EventContext} context `{ request, response, route, params, module, app, view,
 *   authOwner }`, where `module` is `{ id, options, privateOptions }`, `app`
 *   the deployment's read-only data, `view` what a session shows a page and
 *   `authOwner` the id of the module that owns sign-in
 * @returns {ServerEvent}
 */
export function createServerEvent(context) {
  const { request, response, route, params } = context;
  const webRequestValue = webRequest(request, route);
  // SAFETY: `server-module.ts` lets a handler name the JSON shape it expects from the backend and from the client, as `Response.json()` does; the server parses that JSON and hands it on unchecked, which these two members are the only place to state.
  const parsedJson = /** @type {Pick<ServerEvent, "backend" | "readJson">} */ ({
    backend: (/** @type {string} */ path, init = {}) =>
      backend(path, request, init),
    readJson: () => readJson(webRequestValue),
  });
  return {
    ...parsedJson,
    request: webRequestValue,
    params: Object.freeze({ ...params }),
    session: sessionAccess(request, response, context.view),
    cookies: cookieAccess(
      request,
      response,
      context.module.id,
      context.authOwner,
    ),
    backendUrl: (/** @type {string} */ path) => backendUrl(path),
    clientIp: () => clientIp(request),
    module: Object.freeze({
      id: context.module.id,
      options: frozenCopy(context.module.options),
      privateOptions: frozenCopy(context.module.privateOptions),
    }),
    renderEmail: (
      /** @type {string} */ template,
      /** @type {Record<string, unknown>} */ props,
      options = {},
    ) => renderEmailTemplate(template, props, options),
    app: Object.freeze({
      authEstablishEndpoints: Object.freeze([
        ...(context.app?.authEstablishEndpoints ?? []),
      ]),
    }),
    url: new URL(webRequestValue.url),
  };
}

/** @param {unknown} value */
function isResponse(value) {
  return (
    value instanceof Response ||
    (isRecord(value) &&
      isNumber(value.status) &&
      isObjectLike(value.headers) &&
      isFunction(value.headers.get) &&
      "body" in value)
  );
}

/**
 * @param {any} result What a handler answered: any value, of which only
 *   `isResponse` looks
 * @returns {Response}
 */
function asResponse(result) {
  if (isResponse(result))
    // oxlint-disable-next-line typescript/no-unsafe-return -- `isResponse` also accepts a `Response` of another realm by its members (`status`, `headers.get`, `body`), so it cannot be a `value is Response` predicate without claiming members it does not check.
    return result;
  if (result === undefined || result === null)
    return new Response(null, { status: 204 });
  return Response.json(result);
}

/**
 * Writes a handler's answer. The cookies the event wrote are already on the
 * Node response; those of a returned `Response` are added to them. A backend
 * answer the handler relays goes out as the proxy relays one: its `Location`
 * on the frontend's origin when the frontend proxies its path, no cookie of
 * another site its fetch reached.
 *
 * @param {ServerRequest} request
 * @param {ServerResponse} response
 * @param {unknown} result
 * @param {(path: string) => boolean} isProxiedPath
 */
async function writeServerResponse(request, response, result, isProxiedPath) {
  const answer = asResponse(result);
  const cookies = [response.getHeader("set-cookie") ?? []]
    .flat()
    .map(String)
    .concat(relayableCookies(answer));
  answer.headers.forEach((value, name) => {
    if (name === "set-cookie") return;
    response.setHeader(
      name,
      name === "location" && isBackendUrl(answer.url)
        ? relayedLocation(value, answer.url, isProxiedPath)
        : value,
    );
  });
  if (cookies.length) response.setHeader("set-cookie", cookies);
  if (!answer.headers.has("cache-control"))
    response.setHeader("cache-control", "no-store");
  response.writeHead(answer.status, answer.statusText || undefined);
  if (!answer.body || request.method === "HEAD") {
    await answer.body?.cancel();
    response.end();
    return;
  }
  await pipeWebBody(answer.body, response);
}

/**
 * Answers a request with the module route it reached. The route's defaults
 * apply first: a request with a state-changing method needs the frontend's
 * own `Origin` unless the route says otherwise. An error the handler lets
 * through reaches the server's error handling with the cookies written so
 * far.
 *
 * @param {Omit<EventContext, "route"> & { route: import("./module-route-types.mjs").ServerRoute, isProxiedPath: (path: string) => boolean }} context See `createServerEvent`, plus `isProxiedPath(pathname)`:
 *   whether the frontend sends that path to the backend
 */
export async function answerModuleRoute(context) {
  const { request, response, route } = context;
  if (
    route.sameOrigin &&
    !SAFE_METHODS.has(request.method) &&
    !isSameOrigin(request)
  ) {
    json(response, 403, CROSS_ORIGIN_ERROR);
    return;
  }
  const event = createServerEvent(context);
  const result = await route.handler(event);
  await writeServerResponse(request, response, result, context.isProxiedPath);
}
