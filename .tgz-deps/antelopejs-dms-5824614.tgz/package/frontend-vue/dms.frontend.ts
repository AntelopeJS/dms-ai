import { defineAsyncComponent, type Component } from "vue";
import { buildComponents as authBuildComponents } from "./layers/dms-auth/app/entries/component-registry";
import { buildComponents as layoutBuildComponents } from "./layers/dms-layout/app/entries/component-registry";
import { buildComponents as onboardingBuildComponents } from "./layers/dms-onboarding/app/entries/component-registry";
import { buildComponents as uiBuildComponents } from "./layers/dms-ui/app/entries/component-registry";
import {
  type DmsFrontendModule,
  type DmsFrontendSdk,
  useDmsRuntimeConfig,
} from "#dms/frontend-module";
import { lazyPlugin } from "./lazy-plugin";
import authMiddleware from "./layers/dms-auth/app/middleware/auth";
import permissionsPreloadPlugin from "./layers/dms-auth/app/plugins/permissions-preload";
import asyncDataScopePlugin from "./layers/dms-core/app/plugins/async-data-scope";
import homepageRedirectMiddleware from "./layers/dms-layout/app/middleware/homepage-redirect.global";
import moduleRoutingMiddleware from "./layers/dms-layout/app/middleware/module-routing.global";
import pageLeaveGuardMiddleware from "./layers/dms-layout/app/middleware/page-leave-guard.global";
import accessibilityPlugin from "./layers/dms-layout/app/plugins/accessibility";
import colorModePlugin from "./layers/dms-layout/app/plugins/color-mode";
import faviconPlugin from "./layers/dms-layout/app/plugins/favicon";
import interfaceScalePlugin from "./layers/dms-layout/app/plugins/interface-scale";
import fontPreloadPlugin from "./layers/dms-layout/app/plugins/font-preload";
import permissionPreviewPrepaintPlugin from "./layers/dms-layout/app/plugins/permission-preview-prepaint";
import regionalPreferencesPlugin from "./layers/dms-layout/app/plugins/regional-preferences";
import seoPlugin from "./layers/dms-layout/app/plugins/seo";
import sidePanelHostPlugin from "./layers/dms-layout/app/plugins/side-panel-host";
import livePauseSourcePlugin from "./layers/dms-ui/app/plugins/live-pause-source";
import onboardingMiddleware from "./layers/dms-onboarding/app/middleware/onboarding.global";
import onboardingPreloadPlugin from "./layers/dms-onboarding/app/plugins/onboarding-preload";
import closingLayersPlugin from "./layers/dms-ui/app/plugins/closing-layers.client";
import kbdPlatformPlugin from "./layers/dms-ui/app/plugins/kbd-platform";
import registerPlugin from "./layers/dms-ui/app/plugins/register";
import shortcutsPlugin from "./layers/dms-ui/app/plugins/shortcuts";
import tableViewDisplaysPlugin from "./layers/dms-ui/app/plugins/table-view-displays";
import "./layers/dms-layout/app/assets/css/main.css";
import type {} from "./layers/dms-core/app/entries/shared/types/runtime-config";
import type {} from "./layers/dms-core/app/entries/shared/types/app-config";

interface VueModule {
  default: Component;
}

type VueLoader = () => Promise<VueModule>;

const components = {
  ...import.meta.glob<VueModule>([
    "./layers/**/app/components/**/*.vue",
    "!./layers/dms-ui/app/components/form/components/ImagePresentation.vue",
  ]),
  ...uiBuildComponents,
  ...layoutBuildComponents,
  ...authBuildComponents,
  ...onboardingBuildComponents,
};
const customPages = import.meta.glob<VueModule>(
  "./layers/**/app/custom-pages/**/*.vue",
);
const dynamicPages = import.meta.glob<VueModule>(
  "./layers/**/app/pages/**/*.vue",
);
const layouts = import.meta.glob<VueModule>(
  "./layers/**/app/custom-layouts/**/*.vue",
);
const errorPages = import.meta.glob<VueModule>("./layers/**/app/error.vue");

function pascalCase(path: string): string {
  return path
    .replace(/\.vue$/, "")
    .split(/[./_-]+/)
    .filter(Boolean)
    .map((part) => `${part[0].toUpperCase()}${part.slice(1)}`)
    .join("");
}

function componentName(path: string): string {
  const relativePath = path.replace(
    /^.*\/(?:components|build\/components)\//,
    "",
  );
  return pascalCase(relativePath.split("/").at(-1) ?? relativePath);
}

function entryName(path: string, directory: string): string {
  return path
    .replace(new RegExp(`^.*\\/${directory}\\/`), "")
    .replace(/\.vue$/, "");
}

function sortedEntries(
  loaders: Record<string, VueLoader>,
): Array<[string, VueLoader]> {
  return Object.entries(loaders).sort(([left], [right]) =>
    left.localeCompare(right),
  );
}

function lazyComponent(loader: VueLoader): Component {
  return defineAsyncComponent(async () => (await loader()).default);
}

const COMPONENT_ALIASES: Record<
  ReturnType<typeof componentName>,
  Parameters<DmsFrontendSdk["registerComponent"]>[0]
> = {
  ActivityFeed: "ActivityFeedBlock",
  Section: "SectionBlock",
  FieldRow: "FieldRowBlock",
};

function registerComponents(
  sdk: Parameters<DmsFrontendModule["setup"]>[0],
): void {
  const names = new Map<string, string>();
  for (const [path, loader] of sortedEntries(components)) {
    const name = componentName(path);
    const previousPath = names.get(name);
    if (previousPath) {
      throw new Error(
        `Duplicate component name ${name}: ${previousPath}, ${path}`,
      );
    }
    names.set(name, path);
    const component = lazyComponent(loader);
    sdk.registerComponent(name, component);
    const alias = COMPONENT_ALIASES[name];
    if (alias) sdk.registerComponent(alias, component);
  }
}

function registerEntries(
  entries: Record<string, VueLoader>,
  directory: string,
  register: (name: string, component: Component, preload?: VueLoader) => void,
): void {
  sortedEntries(entries).forEach(([path, loader]) => {
    register(entryName(path, directory), lazyComponent(loader), loader);
  });
}

function registerCustomPages(
  sdk: Parameters<DmsFrontendModule["setup"]>[0],
): void {
  sortedEntries(customPages).forEach(([path, loader]) => {
    const name = entryName(path, "custom-pages").replace(/\/index$/, "");
    const component = lazyComponent(loader);
    sdk.registerPage(name, component, loader);
    sdk.registerComponent(pascalCase(name), component);
  });
}

function registerDeferredPlugins(
  sdk: Parameters<DmsFrontendModule["setup"]>[0],
): void {
  sdk.registerPlugin(
    (context) => {
      context.hook("app:mounted", async () => {
        const { installDeferredPlugins } = await import("./deferred-plugins");
        await installDeferredPlugins(context);
      });
    },
    { clientOnly: true },
  );
}

function registerPlugins(sdk: Parameters<DmsFrontendModule["setup"]>[0]): void {
  const clientOnly = { clientOnly: true };
  if (import.meta.env.DEV) {
    sdk.registerPlugin(
      lazyPlugin(
        () => import("./layers/dms-layout/app/plugins/dms-dev-reload.client"),
      ),
      clientOnly,
    );

    sdk.registerPlugin(
      lazyPlugin(() => import("./layers/dms-core/app/plugins/dev-error-log")),
      { ...clientOnly, enforce: "pre" },
    );
  }

  sdk.registerPlugin(asyncDataScopePlugin, { enforce: "pre" });

  sdk.registerPlugin(onboardingPreloadPlugin);
  sdk.registerPlugin(permissionsPreloadPlugin);
  sdk.registerPlugin(colorModePlugin);
  sdk.registerPlugin(permissionPreviewPrepaintPlugin);
  sdk.registerPlugin(fontPreloadPlugin);
  sdk.registerPlugin(interfaceScalePlugin);
  sdk.registerPlugin(accessibilityPlugin);
  sdk.registerPlugin(regionalPreferencesPlugin);
  sdk.registerPlugin(seoPlugin);
  sdk.registerPlugin(faviconPlugin);
  sdk.registerPlugin(sidePanelHostPlugin);

  sdk.registerPlugin(livePauseSourcePlugin, clientOnly);

  sdk.registerPlugin(closingLayersPlugin, clientOnly);
  sdk.registerPlugin(registerPlugin);
  sdk.registerPlugin(shortcutsPlugin);
  sdk.registerPlugin(kbdPlatformPlugin);
  sdk.registerPlugin(tableViewDisplaysPlugin);
  registerDeferredPlugins(sdk);
}

function registerMiddleware(
  sdk: Parameters<DmsFrontendModule["setup"]>[0],
): void {
  const global = { global: true };
  sdk.registerMiddleware("auth", authMiddleware);
  sdk.registerMiddleware(
    "homepage-redirect",
    homepageRedirectMiddleware,
    global,
  );
  sdk.registerMiddleware("module-routing", moduleRoutingMiddleware, global);
  sdk.registerMiddleware("page-leave-guard", pageLeaveGuardMiddleware, global);
  sdk.registerMiddleware("onboarding", onboardingMiddleware, global);
}

const frontendModule: DmsFrontendModule = {
  componentPrefix: "Dms",

  setup(sdk) {
    const runtimeDms = useDmsRuntimeConfig().public.dms;
    if (runtimeDms && typeof window !== "undefined")
      runtimeDms.baseURL = window.location.origin;
    registerPlugins(sdk);
    registerMiddleware(sdk);
    registerComponents(sdk);
    registerCustomPages(sdk);
    registerEntries(dynamicPages, "pages", sdk.registerDynamicPage);
    registerEntries(layouts, "custom-layouts", sdk.registerLayout);
    sortedEntries(errorPages).forEach(([, loader]) => {
      sdk.registerErrorPage(lazyComponent(loader), loader);
    });
    sdk.provide("dmsPublicConfig", sdk.options.public);
  },
};

export default frontendModule;
